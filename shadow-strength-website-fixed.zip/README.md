
  # Shadow strength website prototype

  This is a code bundle for Shadow strength website prototype. The original project is available at https://www.figma.com/design/vBtEPO6qT7W3UdgrKwmyMW/Shadow-strength-website-prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  